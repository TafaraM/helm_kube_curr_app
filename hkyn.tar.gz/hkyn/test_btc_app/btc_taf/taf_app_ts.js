const axios = require('axios');

// Function to fetch Bitcoin price in Euro and Czech Koruna
async function fetchBitcoinPrice() {
  try {
    const response = await axios.get('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=eur,czk');
    
    const bitcoinPriceEUR = response.data.bitcoin.eur;
    const bitcoinPriceCZK = response.data.bitcoin.czk;
    
    console.log(`Bitcoin price in Euro: €${bitcoinPriceEUR}`);
    console.log(`Bitcoin price in Czech Koruna: Kč${bitcoinPriceCZK}`);
  } catch (error) {
    console.error('Error fetching Bitcoin price:', error.message);
  }
}

// Call the function to fetch and display Bitcoin price
fetchBitcoinPrice();

